bookstore
======


What the fuck am I doing right now? Idk but I connected to the git repo so
that's progress.
